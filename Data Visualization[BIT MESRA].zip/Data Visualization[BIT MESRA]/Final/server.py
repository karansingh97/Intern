import pandas as pd
import dash
from flask import Flask,jsonify,request, render_template, request
import os
import csv
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext

app = Flask(__name__)


SparkContext.setSystemProperty("hive.metastore.uris", "thrift://indlin5126.corp.amdocs.com:9083")
sparkSession = (SparkSession.builder.appName('example-pyspark-read-and-write-from-hive').enableHiveSupport().getOrCreate())



@app.route('/home')
def new():
                return render_template("dataflash.html")


@app.route('/')
def index():
                return(' HIve Access Succesfull...enter table/view')

@app.route('/spark/data')
def sparkHiveData():
                dbtblName='test_db.customer'
                res=sparkSession.catalog.refreshTable(dbtblName)

                query = 'SELECT * from test_db.customer'
                df_load = sparkSession.sql(query)
                cursor=df_load.collect()
                
                
                
if __name__== '__main__':
                app.run(host="indlin5126.corp.amdocs.com",port="6333")
                app.run(debug=True)
                conn=hive.connection(host="10.19.87.12",port=10000,username="bdauser",password="bdauser")
