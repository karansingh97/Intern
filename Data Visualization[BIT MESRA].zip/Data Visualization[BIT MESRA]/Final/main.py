import pandas as pd
from flask import Flask,jsonify,request, render_template
import os
import csv
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext

app = Flask(__name__)


SparkContext.setSystemProperty("hive.metastore.uris", "thrift://indlin5126.corp.amdocs.com:9083")
sparkSession = (SparkSession.builder.appName('example-pyspark-read-and-write-from-hive').enableHiveSupport().getOrCreate())



q= input()
dbtblName = 'test_db.customer'
res=sparkSession.catalog.refreshTable(dbtblName)

query = q 
df_load = sparkSession.sql(query)
cursor=df_load.collect()



df_load.write.csv('report.csv')




