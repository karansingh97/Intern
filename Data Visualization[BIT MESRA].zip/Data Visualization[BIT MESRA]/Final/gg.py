

import pandas as pd

import numpy as np
import pyhs2



with pyhs2.connect(host='10.76.248.67',
               port=10000,
               authMechanism="PLAIN",
               user='bdauser',
               password='bdauser',
               database='ADH1005') as conn:
    with conn.cursor() as cur:
        #Show databases
        #print cur.getDatabases()

        #Execute query
        cur.execute("select * from adh_audit")
        val=cur.fetchall()
        columnNames = [a['columnName'] for a in  cur.getSchema()]
        df=pd.DataFrame(data=val,columns=columnNames)
	print df
