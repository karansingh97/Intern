
from pyhive import hive
import pandas as pd
#!/usr/bin/python
from flask import Flask,jsonify,request, render_template
import os
import csv
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext
import jpype
import jaydebeapi

app = Flask(__name__)


SparkContext.setSystemProperty("hive.metastore.uris", "thrift://indlin5220.corp.amdocs.com:10000")
sparkSession = (SparkSession.builder.appName('example-pyspark-read-and-write-from-hive').enableHiveSupport().getOrCreate())

jHome = jpype.getDefaultJVMPath()
jpype.startJVM(jHome, '-Djava.class.path=./lib/jdbc/ojdbc6.jar')
#oracle_con = jaydebeapi.connect('oracle.jdbc.driver.OracleDriver','jdbc:hive2://indlin5220.corp.amdocs.com:10000/ADH1005:')
#oracle_cursor = oracle_con.cursor()

@app.route('/')
def index():
                return('Welcome To Flask REST API !!!')

@app.route('/oracle/count')
def oracleCount():
  tblName = request.args.get("tblName")
  sql = "SELECT count(1) FROM "+tblName
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  return jsonify(result[0][0])

@app.route('/oracle/RiTableTruncate')
def oracleRiTableTruncate():
  sql = "delete from RI_CHECK"
  oracle_cursor.execute(sql)

  oracle_con.commit()
  return "success"

@app.route('/oracle/RiTableStatusTruncate')
def oracleRiTableStatusTruncate():
  sql = "delete from RI_CHECK_status"
  oracle_cursor.execute(sql)
  oracle_con.commit()
  return "success"

@app.route('/oracle/RI_CHECK')
def oracleRiCheckInsert():
  parentTable     = request.args.get("PARENT_TABLE")
  parentKeyColumn = request.args.get("PARENT_KEY_COLUMN")
  childTable      = request.args.get("CHILD_TABLE")
  childKeyColumn  = request.args.get("CHILD_KEY_COLUMN")
  Ind = request.args.get("Ind")
  sql = "INSERT INTO RI_CHECK(PARENT_TABLE,PARENT_KEY_COLUMN,CHILD_TABLE,CHILD_KEY_COLUMN,id_val,EXECUTE_IND)VALUES(\'"+parentTable+"\',\'"+parentKeyColumn+"\',\'"+childTable+"\',\'"+childKeyColumn+"\',(select nvl(max(id_val),0)+1 from RI_CHECK ),\'"+Ind+"\')"
  print sql
  res=oracle_cursor.execute(sql)
  oracle_con.commit()
  print sql
  print res

  return "sucess"

@app.route('/oracle/RI_REFRESH_LIST', methods= ['POST'])
def oracleRiRefreshList():
                
  print "rnair"
  content = request.data
  print content
  #d = json.loads(content)
  #print request.data
  #print d
  #content = request.json  
  #json_data = request.get_json(force=True)
  #print json_data
  #print content           
  #return uuid   
  #return jsonify(request.json)
  #parentTable     = request.args.get("PARENT_TABLE")
  #parentKeyColumn = request.args.get("PARENT_KEY_COLUMN")
  #childTable      = request.args.get("CHILD_TABLE")
  #childKeyColumn  = request.args.get("CHILD_KEY_COLUMN")
  #Ind = request.args.get("Ind")
  #sql = "INSERT INTO RI_CHECK(PARENT_TABLE,PARENT_KEY_COLUMN,CHILD_TABLE,CHILD_KEY_COLUMN,id_val,EXECUTE_IND)VALUES(\'"+parentTable+"\',\'"+parentKeyColumn+"\',\'"+childTable+"\',\'"+childKeyColumn+"\',(select nvl(max(id_val),0)+1 from RI_CHECK ),\'"+Ind+"\')"
  #print sql
  #res=oracle_cursor.execute(sql)
  #oracle_con.commit()
  #print sql
  #print res

  return "sucess"

@app.route('/oracle/RI_CHECK_MAX')
def oracleRiCheckMax():
  sql = "SELECT MAX(ID_VAL) FROM RI_CHECK"
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  return jsonify(result[0][0])  

@app.route('/oracle/RI_CHECK_QUERY')
def oracleRiCheckQuery():
  idVal = request.args.get("idVal")
  sql = "SELECT PARENT_TABLE,PARENT_KEY_COLUMN,CHILD_TABLE,CHILD_KEY_COLUMN,EXECUTE_IND  from RI_CHECK WHERE ID_VAL="+idVal
  print sql
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  #return jsonify(result[0][0])



  if result[0][4] == "Y":
          dbtblName='three_ir_ci.' +(result[0][0])
          res=sparkSession.catalog.refreshTable(dbtblName)
          dbtblNameChild='three_ir_ci.' +(result[0][2])
          res1=sparkSession.catalog.refreshTable(dbtblNameChild)
          parentKey = result[0][1]
          childKey = result[0][3]
          query = "SELECT COUNT(p."+parentKey+") as matching ,(COUNT(C."+childKey+")-COUNT(P."+parentKey+")) as non_matching FROM "+dbtblNameChild+" C LEFT JOIN "+dbtblName+" P ON C."+childKey+"=P."+parentKey
          df_load = sparkSession.sql(query)
          match=df_load.collect()[0]['matching']
          Non_match=df_load.collect()[0]['non_matching']

          sql = "INSERT INTO RI_CHECK_STATUS(RUN_DATE,CHILD_TABLE,CHILD_KEY_COLUMN,Matching_Count,NonMatching_Count)VALUES(CURRENT_TIMESTAMP,\'"+(result[0][2])+"\',\'"+childKey+"\',"+str(match)+","+str(Non_match)+")"
          oracle_cursor.execute(sql)
          oracle_con.commit() 
  return "success"

                



@app.route('/oracle/RI_CHECK_Mail')
def oracleRiMail():
  sql = "SELECT * from ri_check_status where nonmatching_count>0 and to_date(run_date)=to_date(current_date)"
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  #return jsonify(result[0][0])
  filename="/tmp/RiOutput.csv"
  FILE=open(filename,"w");
  output=csv.writer(FILE, dialect='excel')
  for row in result:
          output.writerow(row)
  FILE.close() 
  return "success"



@app.route('/spark/count')
def sparkHiveCount():
                tblName = request.args.get("tblName")
                dbtblName='three_ir_ci.' + tblName
                res=sparkSession.catalog.refreshTable(dbtblName)

                query = 'SELECT count(1) FROM '+dbtblName
                df_load = sparkSession.sql(query)
                cnt=df_load.collect()[0]['count(1)']

                return jsonify(cnt)


@app.route('/spark/data')
def sparkHiveData():
                tblName = request.args.get("tblName")
                dbtblName='three_ir_ci.' + tblName
                res=sparkSession.catalog.refreshTable(dbtblName)

                query = 'SELECT '+tblName+'key FROM '+dbtblName
                df_load = sparkSession.sql(query)
                cursor=df_load.collect()
                
                s="<table style='border:1px solid red'>"
  #s="\<table border=1 width=50\%\>\n"
                
                for row in cursor:
                                s = s + "<tr>"
                                for x in row:
                                                s = s + "<td>" + str(x) + "</td>"
                                s = s + "</tr>"

                return "<html><body>" + s + "</body></html>"

#curl "http://indlin5069.corp.amdocs.com:5000/Recon/reconId?OracleTable=RECON_QUERY&RECON_SQL_TYPE=Target&RECON_RULE_ID=22222"
#@app.route('/Recon/reconId')
#def sparkHiveRecon():
#             HiveDB= request.args.get("HiveDB")
#             ReconSqlType = request.args.get("RECON_SQL_TYPE")
#             
#             ReconRuleId = request.args.get("RECON_RULE_ID")
#
#             print ReconSqlType
#             print ReconRuleId
#             
#             sql = "SELECT to_char(SQL_TXT) FROM RECON_QUERY  WHERE RECON_RULE_ID=\'"+ReconRuleId+"\' and RECON_SQL_TYPE=\'"+ReconSqlType+"\'"
#             print sql 
#             
#             oracle_cursor.prepare(sql)
#             oracle_cursor.execute(sql)
#             query = oracle_cursor.fetchone()[0]
#             #print query
#             df_load = sparkSession.sql('USE THREE_IR_CI')   
#             df_load = sparkSession.sql(query)
#             result=df_load.collect()[0]
#             #print (cnt)         
#             print (result)
#             return jsonify(cnt)


#curl "http://indlin5072.corp.amdocs.com:5000//Spark/ReconQuery//" 
#This Url will execute  the query is receives in the request. The result is send back as a Pipe Delimited String 
@app.route('/Spark/ReconQuery/' ,methods= ['POST'] )
def sparkHiveQuery():
  

  DefaultDatabaseVal= request.args.get("DB")
  query="USE "+DefaultDatabaseVal
  #print (query)
  df_load = sparkSession.sql(query)
  query=request.stream.read()
  #print(query)  
  df_load = sparkSession.sql(query)
  result=df_load.collect()
  #print (result)
  resultString=""
  
  for Row in result:
    resultString = resultString + str(Row[0])+"\n"

  #print  (resultString)
  return (resultString)
  #return jsonify(result)  



if __name__== '__main__':
                app.run(host="indlin5072.corp.amdocs.com",port="5000")
                app.run(debug=True)
                #dir (app) # this command shows all the object with the object
  #SELECT 'Count' As ColumnName, '' As Value, count(*) As Aggregate FROM three_ir_ci.orderactionreason
  #http://indlin5069.corp.amdocs.com:5000/spark/reconquery?hql="SELECT 'Count' As ColumnName, '' As Value, count(*) As Aggregate FROM three_ir_ci.orderactionreason"
conn=hive.connection(host="10.76.248.67",port=10000,username="bdauser",password="bdauser")
df = pd.read_csv('query-hive-5408.csv')
df1 = pd.read_csv('thr.csv')
XX=df['adh_audit.key']
YY=df['adh_audit.application_id']
H=df['adh_audit.status']

