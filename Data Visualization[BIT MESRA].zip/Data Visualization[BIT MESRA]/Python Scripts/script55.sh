#!/usr/bin/bash


#bash -x spark2-submit --master yarn-client --executor-memory 2G --driver-memory 2G  /home/bdauser/karan/py33.py

bash -x spark2-submit --master yarn-client --conf spark.executor.extraLibraryPath=/BDA/irl/adh/TEST_DB/utils/lib/hive-hbase-handler-1.1.0-cdh5.15.0.jar --conf spark.executor.extraClassPath=/BDA/irl/adh/TEST_DB/utils/lib/hive-hbase-handler-1.1.0-cdh5.15.0.jar --executor-memory 8G --driver-memory 8G --driver-class-path=/BDA/irl/adh/TEST_DB/utils/lib/hive-hbase-handler-1.1.0-cdh5.15.0.jar --jars /BDA/irl/adh/TEST_DB/utils/lib/hive-hbase-handler-1.1.0-cdh5.15.0.jar /home/bdauser/karan/py55.py 

