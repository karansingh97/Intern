import pandas as pd
from flask import Flask,jsonify,request, render_template
import os
import csv
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext

app = Flask(__name__)


SparkContext.setSystemProperty("hive.metastore.uris", "thrift://indlin5126.corp.amdocs.com:9083")
sparkSession = (SparkSession.builder.appName('example-pyspark-read-and-write-from-hive').enableHiveSupport().getOrCreate())


@app.route('/')
def index():
                return('Welcome To Flask REST API !!!')

@app.route('/spark/data')
def sparkHiveData():
                dbtblName='test_db.customer'
                res=sparkSession.catalog.refreshTable(dbtblName)

                query = 'SELECT customerkey from test_db.customer'
                df_load = sparkSession.sql(query)
                cursor=df_load.collect()

                s="<table style='border:1px solid red'>"
  #s="\<table border=1 width=50\%\>\n"

                for row in cursor:
                                s = s + "<tr>"
                                for x in row:
                                                s = s + "<td>" + str(x) + "</td>"
                                s = s + "</tr>"

                return "<html><body>" + s + "</body></html>"



if __name__== '__main__':
                app.run(host="indlin5126.corp.amdocs.com",port="5000")
                app.run(debug=True)
                conn=hive.connection(host="10.19.87.12",port=10000,username="bdauser",password="bdauser")


