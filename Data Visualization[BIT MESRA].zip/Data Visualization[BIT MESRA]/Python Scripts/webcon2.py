
from flask import Flask,jsonify,request, render_template
import os
import csv
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.types import *

import jaydebeapi
import pyhs2

app = Flask(__name__)


#/opt/cloudera/parcels//opt/cloudera/parcels/CDH-5.15.0-1.cdh5.15.0.p0.21/lib/hue/apps/hbase/gen-py/

#SUBMIT_ARGS = "--driver-class-path /opt/cloudera/parcels/CDH/lib/hive/lib pyspark-shell"
#SUBMIT_ARGS = "--packages com.databricks:spark-csv_2.11:1.2.0 pyspark-shell"
#os.environ["PYSPARK_SUBMIT_ARGS"] = SUBMIT_ARGS

SparkContext.setSystemProperty("hive.metastore.uris", "thrift://indlin5220.corp.amdocs.com:9083")
sparkSession = (SparkSession.builder.appName('example-pyspark-read-and-write-from-hive').enableHiveSupport().getOrCreate())

jHome = jpype.getDefaultJVMPath()
jpype.startJVM(jHome, '-Djava.class.path=./lib/jdbc/ojdbc6.jar')
oracle_con = jaydebeapi.connect('oracle.jdbc.driver.OracleDriver','jdbc:oracle:thin:DEVCI/DEVCI@incetir006:1521/TIROMS1')
oracle_cursor = oracle_con.cursor()

@app.route('/')
def index():
        return('Welcome To Flask REST API !!!')

@app.route('/oracle/count')
def oracleCount():
  tblName = request.args.get("tblName")
  sql = "use test_db; SELECT count(1) FROM "+tblName
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  return jsonify(result[0][0])



@app.route('/oracle/RI_CHECK_Mail')
def oracleRiMail():
  sql = "SELECT * from ri_check_status where nonmatching_count>0 and to_date(run_date)=to_date(current_date)"
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  #return jsonify(result[0][0])
  filename="/tmp/RiOutput.csv"
  FILE=open(filename,"w");
  output=csv.writer(FILE, dialect='excel')
  for row in result:
          output.writerow(row)
  FILE.close()
  return "success"
#!/usr/bin/python
from flask import Flask,jsonify,request, render_template
import os
import csv
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext
from pyspark.sql.types import *
import jpype
import jaydebeapi
import pyhs2

app = Flask(__name__)


#/opt/cloudera/parcels//opt/cloudera/parcels/CDH-5.15.0-1.cdh5.15.0.p0.21/lib/hue/apps/hbase/gen-py/

#SUBMIT_ARGS = "--driver-class-path /opt/cloudera/parcels/CDH/lib/hive/lib pyspark-shell"
#SUBMIT_ARGS = "--packages com.databricks:spark-csv_2.11:1.2.0 pyspark-shell"
#os.environ["PYSPARK_SUBMIT_ARGS"] = SUBMIT_ARGS

SparkContext.setSystemProperty("hive.metastore.uris", "thrift://indlin5220.corp.amdocs.com:9083")
sparkSession = (SparkSession.builder.appName('example-pyspark-read-and-write-from-hive').enableHiveSupport().getOrCreate())

jHome = jpype.getDefaultJVMPath()
jpype.startJVM(jHome, '-Djava.class.path=./lib/jdbc/ojdbc6.jar')
oracle_con = jaydebeapi.connect('oracle.jdbc.driver.OracleDriver','jdbc:oracle:thin:DEVCI/DEVCI@incetir006:1521/TIROMS1')
oracle_cursor = oracle_con.cursor()

@app.route('/')
def index():
        return('Welcome To Flask REST API !!!')

@app.route('/oracle/count')
def oracleCount():
  tblName = request.args.get("tblName")
  sql = "use test_db; SELECT count(1) FROM "+tblName
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  return jsonify(result[0][0])



@app.route('/oracle/RI_CHECK_Mail')
def oracleRiMail():
  sql = "SELECT * from ri_check_status where nonmatching_count>0 and to_date(run_date)=to_date(current_date)"
  oracle_cursor.execute(sql)
  result = oracle_cursor.fetchall()
  #return jsonify(result[0][0])
  filename="/tmp/RiOutput.csv"
  FILE=open(filename,"w");
  output=csv.writer(FILE, dialect='excel')
  for row in result:
          output.writerow(row)
  FILE.close()
  return "success"

